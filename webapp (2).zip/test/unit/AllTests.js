sap.ui.define([
	"assign5/test/unit/controller/Dashboard.controller"
], function () {
	"use strict";
});
