sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("assign5.controller.ProductDetail", {
            onInit: function () {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("ProductDetail").attachPatternMatched(this._onRouteMatched,this);   
            },
            _onRouteMatched: function (oEvent) {
                var arg = oEvent.getParameter("arguments");
                this.getView().bindElement("/" + arg.selectedProductPath + "/Product");
    
            },
        });
    });
