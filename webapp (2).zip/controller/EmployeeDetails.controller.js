sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("assign5.controller.EmployeeDetails", {
            onInit: function () {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("EmployeeDetails").attachPatternMatched(this._onRouteMatched,this);
            },
            onDashboard:function(oEvent){
                this._oRouter.navTo("RouteDashboard");
            },
            _onRouteMatched: function (oEvent) {
                var arg = oEvent.getParameter("arguments");
                this.getView().bindElement("/" + arg.selectedEmployeePath);
            },
            onSelect: function (oEvent) {
                var path = oEvent.getSource().getBindingContext().getPath().substr(1);
                //MessageToast.show(path);
                this._oRouter.navTo("OrderDetail", {
                    selectedOrderPath: path
                });
            },
            handleCustomerPopover: function (oEvent) {
                //MessageToast.show("customer popover triggered");
                var path1,oClick;
                 path1 = oEvent.getSource().getBindingContext().getPath();
                 oClick = oEvent.getSource();
    
                //create popover
                if (!this._customeroPopover) {
                    //MessageToast.show("if  triggered");
                    Fragment.load({
                        name: "assign5.fragments.CustomerIdPopover",
                        controller: this
                    }).then(function (cPopover) {
                        this._customeroPopover = cPopover;
                        this.getView().addDependent(this._customeroPopover);
                        this._customeroPopover.bindElement(path1 + "/Customer");
                        this._customeroPopover.openBy(oClick);
                    }.bind(this));
                    //MessageToast.show(path);
                } else {
                    //MessageToast.show("else  triggered");
                    this._customeroPopover.bindElement(path1 + "/Customer");
                    this._customeroPopover.openBy(oClick);
                    //MessageToast.show(path);
                }
            }
        });
    });
