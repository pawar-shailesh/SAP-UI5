sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("assign5.controller.Dashboard", {
            onInit: function () {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("RouteDashboard").attachPatternMatched(this._onRouteMatched,this);
               
            },
            onClick: function (oEvent) {
                var t1 =  oEvent.getSource().getBindingContext().getPath().substr(1);
                 this._oRouter.navTo("EmployeeDetails",{
                     selectedEmployeePath :t1
                 });
            }
        });
    });
