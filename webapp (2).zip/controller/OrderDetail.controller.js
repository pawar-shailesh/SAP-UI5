sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,MessageToast) {
        "use strict";

        return Controller.extend("assign5.controller.OrderDetail", {
            onInit: function () {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("OrderDetail").attachPatternMatched(this._onRouteMatched,this);
            },
            onEmployeeDetail:function(oEvent){
                this._oRouter.navTo("EmployeeDetails");
            },
            _onRouteMatched: function (oEvent) {
                var arg = oEvent.getParameter("arguments");
                this.getView().bindElement("/" + arg.selectedOrderPath);
    
            },
            onSelect : function(oEvent){
                var path = oEvent.getSource().getBindingContext().getPath().substr(1);
                // MessageToast.show(path);
                // this._oRouter.navTo("ProductDetail");
                this._oRouter.navTo("ProductDetail", {
                    selectedProductPath: path
                });
            }
        });
    });
