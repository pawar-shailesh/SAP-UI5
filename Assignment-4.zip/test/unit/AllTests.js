sap.ui.define([
	"comyash/assignment4/test/unit/controller/Welcome.controller"
], function () {
	"use strict";
});
